# Week 4 Activity 1 - Local Nakama Multiplayer

This project uses a local Nakama server instead of Heroic Cloud.

## Included features
- Nakama Godot SDK installed
- Device authentication
- Host match
- Join by match ID
- Join random open match
- Leave match
- 2-player relayed realtime sync for movement and jump state
- Basic disconnect handling for remote players
- Simple in-game multiplayer panel

## Local server setup
Run Nakama locally with Docker using the official quick-start, then start the Godot project.
Default connection values used in this project:
- Host: `127.0.0.1`
- Port: `7350`
- Scheme: `http`
- Server key: `defaultkey`

## How to test
1. Start local Nakama.
2. Open the project in Godot.
3. Run one instance and press **Host**.
4. Run a second instance and either:
   - paste the match ID and press **Join**, or
   - press **Join Any**.
5. Move and jump with both players to test realtime sync.
