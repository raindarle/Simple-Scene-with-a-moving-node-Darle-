extends Node

var score := 0

@onready var score_label: Label = $Player/ScoreLabel
@onready var nakama_manager = $"../NakamaManager"

var remote_players := {}

func _ready() -> void:
	if nakama_manager:
		nakama_manager.player_state_received.connect(_on_player_state)
		nakama_manager.player_left.connect(_on_player_left)
		nakama_manager.match_left.connect(_clear_remote_players)

func add_point() -> void:
	score += 1
	print(score)
	score_label.text = " You have " + str(score) + " coin/s! "

func _on_player_state(user_id: String, state: Dictionary) -> void:
	if not remote_players.has(user_id):
		var player = preload("res://scenes/player.tscn").instantiate()
		player.is_local_player = false
		player.name = "RemotePlayer_%s" % user_id.substr(0, 6)
		get_parent().add_child(player)
		remote_players[user_id] = player

	remote_players[user_id].apply_remote_state(state)

func _on_player_left(user_id: String) -> void:
	if not remote_players.has(user_id):
		return

	remote_players[user_id].queue_free()
	remote_players.erase(user_id)

func _clear_remote_players() -> void:
	for player in remote_players.values():
		if is_instance_valid(player):
			player.queue_free()
	remote_players.clear()
