extends Node

const HOST := "127.0.0.1"
const PORT := 7350
const SCHEME := "http"
const SERVER_KEY := "defaultkey"

const OP_PLAYER_STATE := 1

var client: NakamaClient
var session: NakamaSession
var socket: NakamaSocket
var match_id := ""
var socket_connected := false

signal status_changed(message)
signal match_joined(id)
signal match_left()
signal player_state_received(user_id, state)
signal player_left(user_id)

func _ready() -> void:
	await connect_to_server()

func connect_to_server() -> void:
	_emit_status("Connecting to local Nakama server...")
	client = Nakama.create_client(SERVER_KEY, HOST, PORT, SCHEME)
	await authenticate()

func authenticate() -> void:
	var device_id = OS.get_unique_id()
	session = await client.authenticate_device_async(device_id)

	if session == null or session.is_exception():
		_emit_status("Authentication failed.")
		push_error("Authentication failed.")
		return

	socket = Nakama.create_socket_from(client)
	var result = await socket.connect_async(session)
	if result != null and result.is_exception():
		_emit_status("Socket connection failed.")
		push_error("Socket connection failed.")
		return

	socket_connected = true
	socket.received_match_state.connect(_on_match_state)
	socket.received_match_presence.connect(_on_match_presence)
	socket.closed.connect(_on_socket_closed)
	_emit_status("Connected. Ready to host or join.")

func create_match() -> bool:
	if not _socket_ready():
		return false

	if match_id != "":
		await leave_match()

	_emit_status("Creating match...")
	var result = await socket.create_match_async()
	if result == null or result.is_exception():
		_emit_status("Create match failed.")
		return false

	var joined := await _join_match_internal(result.match_id)
	if joined:
		_emit_status("Match created: %s" % result.match_id)
	return joined

func join_match(id: String) -> bool:
	if not _socket_ready():
		return false

	var wanted_id := id.strip_edges()
	if wanted_id == "":
		_emit_status("Match ID is empty.")
		return false

	if match_id != "":
		await leave_match()

	_emit_status("Joining match...")
	return await _join_match_internal(wanted_id)

func join_random_match() -> bool:
	if not _socket_ready():
		return false

	_emit_status("Looking for open matches...")
	var result = await client.list_matches_async(session, 1, 2, 10, false, "", "")
	if result == null or result.is_exception():
		_emit_status("Could not list matches.")
		return false

	if result.matches == null or result.matches.is_empty():
		_emit_status("No open matches found. Host one first.")
		return false

	for found_match in result.matches:
		if found_match.match_id == match_id:
			continue
		var size := int(found_match.size)
		if size < 2:
			return await join_match(found_match.match_id)

	_emit_status("No joinable 2-player match found.")
	return false

func leave_match() -> void:
	if socket == null or match_id == "":
		return

	await socket.leave_match_async(match_id)
	match_id = ""
	_emit_status("Left match.")
	match_left.emit()

func send_player_state(state: Dictionary) -> void:
	if socket == null or match_id == "":
		return

	var payload := {
		"x": state.get("x", 0.0),
		"y": state.get("y", 0.0),
		"vx": state.get("vx", 0.0),
		"vy": state.get("vy", 0.0),
		"flip_h": state.get("flip_h", false),
		"moving": state.get("moving", false),
		"jumping": state.get("jumping", false),
		"on_floor": state.get("on_floor", true),
		"time": Time.get_ticks_msec()
	}

	await socket.send_match_state_async(match_id, OP_PLAYER_STATE, JSON.stringify(payload))

func _join_match_internal(id: String) -> bool:
	var result = await socket.join_match_async(id)
	if result == null or result.is_exception():
		_emit_status("Join match failed.")
		return false

	match_id = id
	_emit_status("Joined match: %s" % match_id)
	match_joined.emit(match_id)
	return true

func _on_match_state(state) -> void:
	if state.op_code != OP_PLAYER_STATE:
		return

	if state.presence == null:
		return

	var text_data := ""
	if state.data is String:
		text_data = state.data
	else:
		text_data = state.data.get_string_from_utf8()

	var json = JSON.parse_string(text_data)
	if typeof(json) != TYPE_DICTIONARY:
		return

	player_state_received.emit(state.presence.user_id, json)

func _on_match_presence(event) -> void:
	for presence in event.leaves:
		player_left.emit(presence.user_id)
		_emit_status("A player disconnected.")

func _on_socket_closed() -> void:
	socket_connected = false
	match_id = ""
	_emit_status("Socket closed. Start Nakama and reconnect.")
	match_left.emit()

func _socket_ready() -> bool:
	if socket == null or not socket_connected:
		_emit_status("Socket not ready. Check if local Nakama is running.")
		return false
	return true

func _emit_status(message: String) -> void:
	print(message)
	status_changed.emit(message)
