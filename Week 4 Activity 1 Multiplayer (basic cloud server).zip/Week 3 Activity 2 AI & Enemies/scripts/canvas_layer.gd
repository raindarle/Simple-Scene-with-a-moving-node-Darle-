extends CanvasLayer

@onready var nakama_manager = $"../NakamaManager"
@onready var match_id_input: LineEdit = $MatchIdInput
@onready var status_label: Label = $StatusLabel
@onready var current_match_label: Label = $CurrentMatchLabel

func _ready() -> void:
	nakama_manager.status_changed.connect(_on_status_changed)
	nakama_manager.match_joined.connect(_on_match_joined)
	nakama_manager.match_left.connect(_on_match_left)
	_on_status_changed("Waiting for connection...")

func _on_host_button_pressed() -> void:
	await nakama_manager.create_match()

func _on_join_button_pressed() -> void:
	await nakama_manager.join_match(match_id_input.text)

func _on_join_random_button_pressed() -> void:
	await nakama_manager.join_random_match()

func _on_leave_button_pressed() -> void:
	await nakama_manager.leave_match()

func _on_status_changed(message: String) -> void:
	status_label.text = message

func _on_match_joined(id: String) -> void:
	current_match_label.text = "Current Match: " + id
	match_id_input.text = id

func _on_match_left() -> void:
	current_match_label.text = "Current Match: None"
