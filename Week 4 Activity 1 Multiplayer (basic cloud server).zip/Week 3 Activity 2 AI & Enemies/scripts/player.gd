extends CharacterBody2D

const SPEED := 130.0
const JUMP_VELOCITY := -300.0
const REMOTE_LERP_SPEED := 12.0
const SYNC_INTERVAL := 0.08

@export var animated_sprite_2d: AnimatedSprite2D

var is_local_player := true
var remote_target_position := Vector2.ZERO
var remote_flip_h := false
var last_sent_position := Vector2.ZERO
var sync_timer := 0.0

func _ready() -> void:
	remote_target_position = global_position
	last_sent_position = global_position

func _physics_process(delta: float) -> void:
	if is_local_player:
		_process_local_player(delta)
	else:
		_process_remote_player(delta)

func _process_local_player(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta

	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	var direction := Input.get_axis("ui_left", "ui_right")
	if direction != 0:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	_update_facing(direction)
	move_and_slide()
	_send_state_if_needed(delta, direction)

func _process_remote_player(delta: float) -> void:
	global_position = global_position.lerp(remote_target_position, REMOTE_LERP_SPEED * delta)
	animated_sprite_2d.flip_h = remote_flip_h

func _update_facing(direction: float) -> void:
	if direction > 0:
		animated_sprite_2d.flip_h = true
	elif direction < 0:
		animated_sprite_2d.flip_h = false

func _send_state_if_needed(delta: float, direction: float) -> void:
	sync_timer += delta
	var moved_far := global_position.distance_to(last_sent_position) > 4.0
	var important_action := Input.is_action_just_pressed("ui_accept") or absf(direction) > 0.0 or absf(velocity.y) > 1.0

	if sync_timer < SYNC_INTERVAL and not moved_far and not important_action:
		return

	sync_timer = 0.0
	last_sent_position = global_position

	var nakama_manager = get_node_or_null("/root/Game/NakamaManager")
	if nakama_manager:
		nakama_manager.send_player_state({
			"x": global_position.x,
			"y": global_position.y,
			"vx": velocity.x,
			"vy": velocity.y,
			"flip_h": animated_sprite_2d.flip_h,
			"moving": absf(direction) > 0.0,
			"jumping": not is_on_floor(),
			"on_floor": is_on_floor()
		})

func apply_remote_state(state: Dictionary) -> void:
	remote_target_position = Vector2(
		float(state.get("x", global_position.x)),
		float(state.get("y", global_position.y))
	)
	remote_flip_h = bool(state.get("flip_h", false))
